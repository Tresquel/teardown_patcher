function init()
    Menu()
end

function tick()
    Menu()
end